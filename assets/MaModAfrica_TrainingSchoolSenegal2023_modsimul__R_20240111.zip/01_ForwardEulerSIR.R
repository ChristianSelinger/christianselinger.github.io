deltaT=0.05#step size
maxTime=15#observations of influenza outbreak in days
timesteps<-seq(0,maxTime,deltaT)#time points

initial.condition<-c(S=762,I=1,R=0)##start with one infected person
X<-data.frame(
  matrix(rep(0,length(timesteps)*3),nrow=length(timesteps))
)
names(X)<-c("S","I","R")
X[1,1:3]<-initial.condition

beta<-1.1
gamma<-0.5
N<-763


for(i in c(1:(length(timesteps)-1))){
  X[i+1,1] = X[i,1] + deltaT*(-beta*X[i,2]/N*X[i,1])
  X[i+1,2] = X[i,2] + deltaT*(beta*X[i,2]/N*X[i,1] - gamma*X[i,2])
  X[i+1,3] = X[i,3] + deltaT*(gamma*X[i,2])
}
X$days<-timesteps
plot(X$I)

library(ggplot2)
X%>%
  pivot_longer(col=-days)%>%
  ggplot(aes(x=days,y=value))+
  geom_point()+
  geom_line(aes(color=name))
