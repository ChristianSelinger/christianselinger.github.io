###The data
influenzaEngland1978School<-
  data.frame(time=c(1:14),
             date=as.Date(c("1978-01-22","1978-01-23","1978-01-24","1978-01-25",
                            "1978-01-26","1978-01-27","1978-01-28","1978-01-29","1978-01-30",
                            "1978-01-31","1978-02-01","1978-02-02","1978-02-03","1978-02-04")),
             inBed=c(3,8,26,76,225,298,258,233,189,128,68,29,14,4),
             convalescent=c(0,0,0,0,9,17,105,162,176,166,150,85,47,20),
             total=rep(763,14))

library(deSolve)
library(ggplot2)
library(tidyverse)

SIR.model<-function(time,state,parms){
  with(as.list(c(state,parms)), { 
    
    beta=parms[1]; gamma=parms[2]
    S=state[1]; I=state[2]; R=state[3]; N=S+I+R
    
    dS= - beta*I*S/N
    dI= beta*I*S/N - gamma*I
    dR= gamma*I
    
    return(list(c(dS,dI,dR)))
  })
}

time.points<-seq(0,nrow(influenzaEngland1978School),1)##time unit in days
initial.condition<-c(S=762,I=1,R=0)##start with one infected person
parameters<-c(beta=1.1,gamma=0.5)

as.data.frame(ode(initial.condition,time.points,SIR.model,parameters))->solution_SIR

##lets plot the model output on top of the data
ggplot(merge(solution_SIR,influenzaEngland1978School))+
  geom_line(aes(x=time,y=I),color="darkgreen")+
  geom_point(aes(x=time,y=inBed))

