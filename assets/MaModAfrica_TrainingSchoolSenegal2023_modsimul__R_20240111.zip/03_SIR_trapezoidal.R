# SIR model using trapezoidal scheme

# Function to calculate SIR model
sir_model <- function(beta, gamma, S0, I0, R0, N, days) {
  dt <- 1  # Time step
  S <- numeric(days)
  I <- numeric(days)
  R <- numeric(days)
  
  S[1] <- S0
  I[1] <- I0
  R[1] <- R0
  
  for (t in 1:(days - 1)) {
    dS <- (-beta * S[t] * I[t] / N) * dt
    dI <- ((beta * S[t] * I[t] / N) - (gamma * I[t])) * dt
    dR <- (gamma * I[t]) * dt
    
    S[t + 1] <- S[t] + 0.5 * (dS + (-beta * S[t + 1] * (I[t] + dI) / N) * dt)
    I[t + 1] <- I[t] + 0.5 * (dI + ((beta * S[t + 1] * (I[t] + dI) / N) - (gamma * (I[t] + dI))) * dt)
    R[t + 1] <- R[t] + 0.5 * (dR + (gamma * (I[t] + dI)) * dt)
  }
  
  return(list(S = S, I = I, R = R))
}

# Parameters
beta <- 0.3  # Infection rate
gamma <- 0.1  # Recovery rate
S0 <- 990  # Initial susceptible population
I0 <- 10   # Initial infected population
R0 <- 0    # Initial recovered population
N <- S0 + I0 + R0  # Total population
days <- 100  # Simulation days

# Run the SIR model
result <- sir_model(beta, gamma, S0, I0, R0, N, days)

# Plotting the results
plot(1:days, result$S, type = "l", col = "blue", xlab = "Days", ylab = "Population", main = "SIR Model - Trapezoidal Scheme")
lines(1:days, result$I, col = "red")
lines(1:days, result$R, col = "green")
legend("topright", legend = c("Susceptible", "Infected", "Recovered"), col = c("blue", "red", "green"), lty = 1)
