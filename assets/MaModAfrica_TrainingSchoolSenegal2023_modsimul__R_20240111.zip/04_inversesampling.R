set.seed(123)##fix the random number seed

N=50000
lambda=3##rate for the exponential distribution
U<-runif(N)
X<-log(1-U)/-lambda##inverse sampling
Y=rexp(N,lambda)##built-in random samples from exponential distribution

plot(sort(X),sort(Y))##compare
