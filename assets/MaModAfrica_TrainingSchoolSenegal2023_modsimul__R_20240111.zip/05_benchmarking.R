library(microbenchmark)

Fibonacci_recursive<-function(n){
  if(n<3){result=1}else{
    result=Fibonacci_recursive(n-1)+Fibonacci_recursive(n-2)}
  return(result)
}

Fibonacci_dynamic<-function(n){
  result=c(1,1)
  for(i in c(3:n)){
    result=c(result,result[i-1]+result[i-2])
  }
  result=result[n]
  return(result)
}


##benchmarking computing time
n <- 10
microbenchmark(
  Fibonacci_recursive(n),
  Fibonacci_dynamic(n)
)

##runtime
run_time<-function(func,N=30){
  rt<-NULL
  for(i in c(1:N)){
    rt<-c(rt,system.time(eval(func)(i))[[1]])
  }
  out=data.frame(n=c(1:N),runtime=rt,func=deparse(substitute(func)))
  return(out)
}

##let's plot the runtime
bind_rows(run_time(Fibonacci_recursive),
		run_time(Fibonacci_dynamic))%>%
	ggplot()+
	geom_line(aes(x=n,y=runtime,color=func))
