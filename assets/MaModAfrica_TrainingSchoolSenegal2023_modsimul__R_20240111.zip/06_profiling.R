rm(list=ls())

Fibonacci_dynamic<-function(n){
  result=c(1,1)
  for(i in c(3:n)){
    result=c(result,result[i-1]+result[i-2])
  }
  result=result[n]
  return(result)
}

Rprof(memory.profiling = TRUE)
Fibonacci_dynamic(30)
Rprof(NULL)    ## Turn off the profiler
summaryRprof()


rm(list=ls())

Fibonacci_recursive<-function(n){
  if(n<3){result=1}else{
    result=Fibonacci_recursive(n-1)+Fibonacci_recursive(n-2)}
  return(result)
}

Rprof(memory.profiling = TRUE)
Fibonacci_recursive(30)
Rprof(NULL)    ## Turn off the profiler
summaryRprof()

