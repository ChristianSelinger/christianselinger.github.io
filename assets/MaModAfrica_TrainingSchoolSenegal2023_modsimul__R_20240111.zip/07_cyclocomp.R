library(cyclocomp)
cyclocomp(Fibonacci_recursive)
cyclocomp(Fibonacci_dynamic)

##another example
is_even<-function(n){
  result=NULL
  if(n%%2==0){
    result=T
  }else{
    result=F
  }
  return(result)
}

is_even_better<-function(n){
  return(n%%2==0)
}

cyclocomp(is_even)
cyclocomp(is_even_better)