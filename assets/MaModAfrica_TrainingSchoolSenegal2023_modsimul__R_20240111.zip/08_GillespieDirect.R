###pedestrian way
Gillespie_direct<-function(N=763,seed=123,Iinit=1,Nit=1000,parameters=c(beta=2,gamma=0.5)){
  set.seed(seed)
  ##intial conditions
  states<-c(time=0,S=N-Iinit,I=Iinit,R=0)
  traj<-rbind(c(time=0,S=N,I=0,R=0),c(time=0,S=N-Iinit,I=Iinit,R=0))
  ##events:
  rates=c(rep(parameters['beta']*states['I']/N,states['S']),
    rep(parameters['gamma'],states['I']))
    
    for (it in 1:Nit){
        if(tail(traj[,'I'],1)==0){
            break
        }
    
    states=traj[nrow(traj),]
    rates=c(rep(parameters['beta']*states['I']/N,states['S']),
            rep(parameters['gamma'],states['I']))
    time_to_event=rexp(n=1,rate=sum(rates))
    which_event=sample(x=names(rates),size=1,prob=rates/sum(rates))
    #stoichiometric update
    if(which_event=="beta"){
      print("new infection")
      traj<-rbind(traj,
                    states+c(time_to_event,-1,+1,0))
    }
    if(which_event=="gamma"){
      print("clearance")
      traj<-rbind(traj,
                    states+c(time_to_event,0,-1,+1))
    }
    }
    traj<-as.data.frame(tail(traj,-1))
    traj$seed<-seed
    return(traj)
}
out1<-Gillespie_direct(N=763,seed=123,Nit=1500,parameters=c(beta=1.7,gamma=0.44))

## with the R package GillespieSSA
library(GillespieSSA)

parms <- c(beta=1.7/763, gamma=0.44)
x0 <- c(S=763,I=1,R=0)
a <- c("beta*S*I","gamma*I")
nu <- matrix(c(-1,0,+1,-1,0,+1),nrow=3,byrow=TRUE)
out2 <- ssa(x0,a,nu,parms,tf=1500,method=ssa.d(),simName="SIR model")

## lets compare
plot(out1$t,out1$I, type="l", col="red" )
par(new=TRUE)
plot(out2$data[,"t"],out2$data[,"I"], type="l", col="green",axes=F)



