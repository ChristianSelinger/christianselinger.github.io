library(GillespieSSA)

##tau-leap
N <- 763
parms <- c(beta=1.7/N, gamma=0.44)
x0 <- c(S=N-1,I=1,R=0)
a <- c("beta*S*I","gamma*I")
nu <- matrix(c(-1,0,+1,-1,0,+1),nrow=3,byrow=TRUE)
out3 <- ssa(x0,a,nu,parms,tf=1500,method=ssa.etl(tau =0.3),simName="SIRmodel")

##optimized tau-leap
out4 <- ssa(x0,a,nu,parms,tf=1500,method=ssa.otl(epsilon = 0.03, nc = 10, hor = NA_real_, dtf = 10,nd=100),simName="SIRmodel")

##let's compare all methods for a single stochastic run 
bind_rows(data.frame(t=out1$t,I=out1$I,method="pedestrian"),
          data.frame(t=out2$data[,"t"],I=out2$data[,"I"],method="GillespieSSA-direct"),
          data.frame(t=out3$data[,"t"],I=out3$data[,"I"],method="GillespieSSA-tau_leap"),
          data.frame(t=out4$data[,"t"],I=out4$data[,"I"],method="GillespieSSA-tau_leap_opt"),
          )%>%
          ggplot()+
            geom_line(aes(x=t,y=I,group=method,color=method))+
            #geom_point(data=influenza_england_1978_school,aes(x=time,y=in_bed))+
            theme_bw()

## let's do 59 stochastic runs
out1=out4<-NULL
for (s in c(1:50)){
out1tmp<-Gillespie_direct(N=763,seed=s,Nit=1500,parameters=c(beta=1.7,gamma=0.44))
    out1<-rbind(out1,
                data.frame(t=out1tmp$time,I=out1tmp$I,seed=s))

    set.seed(s)
    out4tmp <- ssa(x0,a,nu,parms,tf=1500,method=ssa.otl(epsilon = 0.03, nc = 10, hor = NA_real_, dtf =10,nd=100),simName="SIRmodel")
    out4<-rbind(out4,
                data.frame(t=out4tmp$data[,"t"],I=out4tmp$data[,"I"],seed=s))
}
out1$method="pedestrian"
out4$method="GillespieSSA-tau_leap_opt"

bind_rows(out1,
          out4)%>%
          ggplot()+
            geom_line(aes(x=t,y=I,group=paste(seed,method),color=method))+
            #geom_point(data=influenza_england_1978_school,aes(x=time,y=in_bed))+
            theme_bw()
