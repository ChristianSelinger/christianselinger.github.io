library(GillespieSSA)
library(tidyverse)

##simple Ross-McDonald model, rates per day
set.seed(5)
finalT=365*2
H <- 1000
VectorHumanRatio<-5
VectorBirthDeathRatio<-1##demographic equilibrium
AverageDurationUntreatedInfection<-20
parms <- c(alpha=0.1, 
           gamma=1/AverageDurationUntreatedInfection, 
           beta=0.08, 
           mu=1/10)
parms[["delta"]]<-parms[["mu"]]*VectorBirthDeathRatio
###basic reproductin number:
R0=sqrt(parms[["alpha"]]*parms[["beta"]]*VectorHumanRatio/(parms[["mu"]]*parms[["gamma"]]))
print(paste0("R0 is: ",round(R0,4)))
I0 <- 1
V0 <- 8
x0 <- c(S=H-I0,I=I0,U=H*VectorHumanRatio-V0,V=V0)
a <- c("alpha*S*V/H","gamma*I","beta*U*I/H","mu*U","mu*V","delta*U","delta*V")
nu <- matrix(c(-1,+1,0,0,0,0,0,
               1,-1,0,0,0,0,0,
               0,0,-1,-1,0,1,1,
               0,0,+1,0,-1,0,0),nrow=4,byrow=TRUE)
out3 <- ssa(x0,a,nu,parms,tf=finalT,method=ssa.etl(tau =0.3),simName="SIRmodel")
RossMcDonald_gillespietau<-out3$data%>%as.data.frame
RossMcDonald_gillespietau$type<-"Gillespie tau-leap"

##compare to ODE model
library("deSolve")
RossMcDonald.model<-function(time,state,parms){
  with(as.list(c(state,parms)), { 
    
    alpha=parms[1]; gamma=parms[2]; beta=parms[3]; mu=parms[4]; delta=parms[5]
    S=state[1]; I=state[2]; U=state[3]; V=state[4]; H=S+I; M=U+V
    
    dS= - alpha*V*S/H + gamma*I
    dI= alpha*V*S/H - gamma*I
    dU= -beta*U*I/H + mu*M-delta*U
    dV= beta*U*I/H-delta*V
    
    return(list(c(dS,dI,dU,dV)))
  })
}
time.points<-seq(0,finalT,1)##time unit in days

ode(x0,time.points,RossMcDonald.model,parms)%>%
  as.data.frame->RossMcDonald_ode
RossMcDonald_ode$type<-"ODE"
RossMcDonald_ode$t<-RossMcDonald_ode$time

bind_rows(RossMcDonald_ode,
          RossMcDonald_gillespietau)%>%
  ggplot()+
  geom_line(aes(x=t,y=I,color=type))

