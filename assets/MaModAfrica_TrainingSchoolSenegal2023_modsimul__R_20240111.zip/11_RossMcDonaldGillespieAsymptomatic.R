library(GillespieSSA)
library(tidyverse)

##simple Ross-McDonald model, rates per day
finalT=365*2
H <- 10000
VectorHumanRatio<-5
VectorBirthDeathRatio<-1##demographic equilibrium
AverageDurationUntreatedInfectionHigh<-20
AverageDurationUntreatedInfectionLow<-15
AverageDurationTreatedInfection<-10
TransmissionHighLowRatio<-5##84/16
beta<-0.08

parms <- c(alpha=2,
           pimC=0.05,
           pimH=0.17,
           pimL=0.78,
           gammaC=1/AverageDurationTreatedInfection,
           gammaH=1/AverageDurationUntreatedInfectionHigh,
           gammaL=1/AverageDurationUntreatedInfectionLow,
           betaC=0.03,
           betaH=beta,
           betaL=beta/TransmissionHighLowRatio,
           mu=1/10)
parms[["delta"]]<-parms[["mu"]]*VectorBirthDeathRatio
###basic reproductin number:
Ic0 <- 20
Ih0 <- 5
Il0 <- 10
V0 <- 8
x0 <- c(S=H-Ic0-Ih0-Il0,Ic=Ic0,Ih=Ih0,Il=Il0,U=H*VectorHumanRatio-V0,V=V0)
a <- c("alpha*pimC*S*V/H","alpha*pimH*S*V/H","alpha*pimL*S*V/H",
       "gammaC*Ic","gammaH*Ih","gammaL*Il",
       "betaC*U*Ic/H","betaH*U*Ih/H","betaL*U*Il/H",
       "delta*U","delta*V","mu*U","mu*V")

##stoichiometric vectors
zeta<-list()

##infection in humans from vector bites
zeta[[1]]<-c(-1,1,0,0,0,0)
zeta[[2]]<-c(-1,0,1,0,0,0)
zeta[[3]]<-c(-1,0,0,1,0,0)

##humans become susceptible again/clearance of infection
zeta[[4]]<-c(+1,-1,0,0,0,0)
zeta[[5]]<-c(+1,0,-1,0,0,0)
zeta[[6]]<-c(+1,0,0,-1,0,0)

##mosquitoes bite infected humans
zeta[[7]]<-c(0,0,0,0,-1,+1)
zeta[[8]]<-c(0,0,0,0,-1,+1)
zeta[[9]]<-c(0,0,0,0,-1,+1)

##vector vital dynamics
zeta[[10]]<-c(0,0,0,0,-1,0)
zeta[[11]]<-c(0,0,0,0,0,-1)
zeta[[12]]<-c(0,0,0,0,1,0)
zeta[[13]]<-c(0,0,0,0,1,0)

nu<-do.call(cbind,zeta)

output<-NULL
for (s in 1:10){
  set.seed(s)
outAsympt <- ssa(x0,a,nu,parms,tf=finalT,method=ssa.etl(tau =0.3),simName="MalariaToy_asymptomatic")
#outAsympt <- ssa(x0,a,nu,parms,tf=finalT,method=ssa.otl(),simName="MalariaToy_asymptomatic")
#outAsympt <- ssa(x0,a,nu,parms,tf=finalT,method=ssa.d(),simName="MalariaToy_asymptomatic")

outAsympt<-outAsympt$data%>%as.data.frame
outAsympt$seed<-s

output<-rbind(output,
              outAsympt)
}
output%>%
  pivot_longer(-c(t,seed))%>%
  ggplot()+
  geom_line(aes(x=t,y=value,color=name,group=seed))+
  facet_wrap(~name,scale="free")+
  scale_color_discrete(name="")+
  scale_x_continuous(name="days")+
  theme_bw()->plot_toymalaria_asympt

ggsave(file="GillespieMalariaToyAsymptotic.png",width=8,height=3)
plot_toymalaria_asympt
dev.off()

