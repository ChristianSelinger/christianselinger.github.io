library(GillespieSSA)
library(tidyverse)

##simple Ross-McDonald model, rates per day
finalT=365*0.25
H <- 10000
VectorHumanRatio<-5
VectorBirthDeathRatio<-1##demographic equilibrium
AverageDurationUntreatedInfectionHigh<-20
AverageDurationUntreatedInfectionLow<-15
AverageDurationTreatedInfection<-10
TransmissionHighLowRatio<-5##84/16
beta<-0.08

parms <- c(alpha=0.1,
           pimC=0.05,
           pimH=0.17,
           pimL=0.78,
           gammaC=1/AverageDurationTreatedInfection,
           gammaH=1/AverageDurationUntreatedInfectionHigh,
           gammaL=1/AverageDurationUntreatedInfectionLow,
           betaC=0.03,
           betaH=beta,
           betaL=beta/TransmissionHighLowRatio,
           mu=1/10,
           Tl=0,
           Th=0,
           MDA=0,
           r=0)
parms[["delta"]]<-parms[["mu"]]*VectorBirthDeathRatio
###initial condition at equilibrium
Ic0 <- 20
Ih0 <- 100
Il0 <- 400
V0 <- 500
x0 <- c(S=H-Ic0-Ih0-Il0,Ic=Ic0,Ih=Ih0,Il=Il0,U=H*VectorHumanRatio-V0,V=V0,`T`=0)
a <- c("alpha*pimC*S*V/H","alpha*pimH*S*V/H","alpha*pimL*S*V/H",
       "gammaC*Ic","gammaH*Ih","gammaL*Il",
       "betaC*U*Ic/H","betaH*U*Ih/H","betaL*U*Il/H",
       "delta*U","delta*V","mu*U","mu*V",
       "Th*Ih","Tl*Il",
       "MDA*S",
       "r*T")

##stoichiometric vectors
zeta<-list()

##infection in humans from vector bites
zeta[[1]]<-c(-1,1,0,0,0,0,0)
zeta[[2]]<-c(-1,0,1,0,0,0,0)
zeta[[3]]<-c(-1,0,0,1,0,0,0)

##humans become susceptible again/clearance of infection
zeta[[4]]<-c(+1,-1,0,0,0,0,0)
zeta[[5]]<-c(+1,0,-1,0,0,0,0)
zeta[[6]]<-c(+1,0,0,-1,0,0,0)

##mosquitoes bite infected humans
zeta[[7]]<-c(0,0,0,0,-1,+1,0)
zeta[[8]]<-c(0,0,0,0,-1,+1,0)
zeta[[9]]<-c(0,0,0,0,-1,+1,0)

##vector vital dynamics
zeta[[10]]<-c(0,0,0,0,-1,0,0)
zeta[[11]]<-c(0,0,0,0,0,-1,0)
zeta[[12]]<-c(0,0,0,0,1,0,0)
zeta[[13]]<-c(0,0,0,0,1,0,0)

##test and treat, move Ih and Il to P
zeta[[14]]<-c(0,0,-1,0,0,0,+1)
zeta[[15]]<-c(0,0,0,-1,0,0,+1)

##MDA, move also S to P
zeta[[16]]<-c(-1,0,0,0,0,0,+1)

##move P back to S
zeta[[17]]<-c(+1,0,0,0,0,0,-1)

nu<-do.call(cbind,zeta)

###Let's run the Gillespie-tau algorithm with initial conditions obtained from the endemic equilibrium of the counterfactual
output<-NULL
###counterfactual
parms[["Tl"]]=parms[["Th"]]=parms[["MDA"]]<-0
for (s in 1:10){
  set.seed(s)
  outAsympt <- ssa(x0,a,nu,parms,tf=finalT,method=ssa.etl(tau =0.1),simName="MalariaToy_asymptomatic")
  
  outAsympt<-rbind(cbind(data.frame(t=0),t(x0)),
                   outAsympt$data%>%as.data.frame
  )
  outAsympt$seed<-s
  
  output<-rbind(output,
                outAsympt)
}
output%>%group_by(seed)%>%slice_max(t)%>%unique%>%ungroup->endemic_eq

output<-NULL
###counterfactual now with endemic equilibrium starting conditions, we need less time points
parms[["Tl"]]=parms[["Th"]]=parms[["MDA"]]<-0
for (s in 1:10){
  set.seed(s)
  x0<-endemic_eq%>%
    filter(seed==s)%>%
    select(-c(t,seed))%>%unlist
  outAsympt <- ssa(x0,a,nu,parms,tf=finalT,method=ssa.etl(tau =0.1),simName="MalariaToy_asymptomatic")
  
  outAsympt<-rbind(cbind(data.frame(t=0),t(x0)),
                   outAsympt$data%>%as.data.frame
  )
  outAsympt$seed<-s
  
  output<-rbind(output,
                outAsympt)
}
output$setting<-"counterfactual"
###test and treat
parms[["Tl"]]=0.15;parms[["Th"]]=0.95;parms[["MDA"]]<-0
parms[["r"]]=1/30

for (s in 1:10){
  set.seed(s)
  x0<-endemic_eq%>%
    filter(seed==s)%>%
    select(-c(t,seed))%>%unlist
  outAsympt <- ssa(x0,a,nu,parms,tf=finalT,method=ssa.etl(tau =0.1),simName="MalariaToy_asymptomatic")
  
  outAsympt<-outAsympt$data%>%as.data.frame
  outAsympt$seed<-s
  outAsympt$setting<-"test&treat"
  
  
  output<-rbind(output,
                outAsympt)
}
###MDA
parms[["Tl"]]=0.98;parms[["Th"]]=0.98;parms[["MDA"]]<-0.98
for (s in 1:10){
  set.seed(s)
  x0<-endemic_eq%>%
    filter(seed==s)%>%
    select(-c(t,seed))%>%unlist
  outAsympt <- ssa(x0,a,nu,parms,tf=finalT,method=ssa.etl(tau =0.1),simName="MalariaToy_asymptomatic")
  
  outAsympt<-outAsympt$data%>%as.data.frame
  outAsympt$seed<-s
  outAsympt$setting<-"MDA"
  
  
  output<-rbind(output,
                outAsympt)
}

output%>%
  mutate(grouping=as.factor(paste0(seed,setting)))->output

output%>%
  pivot_longer(-c(t,grouping,seed,setting))%>%
  filter(!(name%in%c("U","V")))%>%
  ggplot()+
  geom_line(aes(x=t,y=value,color=setting,group=grouping))+
  facet_wrap(~name,scale="free")+
  scale_color_discrete(name="")+
  scale_x_continuous(name="days")+
  theme_bw()->plot_toymalaria_asympt_treat

ggsave(file="GillespieMalariaToyAsymptoticTreat.png",width=8,height=3)
plot_toymalaria_asympt_treat
dev.off()
