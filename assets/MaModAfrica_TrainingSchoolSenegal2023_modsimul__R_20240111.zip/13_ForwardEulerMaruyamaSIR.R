deltaT=0.05#step size
maxTime=15#observations of influenza outbreak in days
timesteps<-seq(0,maxTime,deltaT)#time points
N<-762
I0<-1

initial.condition<-c(S=N-I0,I=I0,R=0)##start with one infected person
X<-data.frame(
  matrix(rep(0,length(timesteps)*3),nrow=length(timesteps))
)
names(X)<-c("S","I","R")
X[1,1:3]<-initial.condition

beta<-1.1
gamma<-0.5

set.seed(123)
for(i in c(1:(length(timesteps)-1))){
  eta=rnorm(2)
  X[i+1,1] = X[i,1] + deltaT*(-beta*X[i,2]/N*X[i,1]) + sqrt(deltaT)*(-sqrt(beta*X[i,2]/N*X[i,1])*eta[1])
  X[i+1,2] = X[i,2] + deltaT*(beta*X[i,2]/N*X[i,1] - gamma*X[i,2]) + sqrt(deltaT)*(sqrt(beta*X[i,2]/N*X[i,1])*eta[1]-sqrt(gamma*X[i,2])*eta[2]) 
  X[i+1,3] = X[i,3] + deltaT*(gamma*X[i,2]) + sqrt(deltaT)*(-sqrt(gamma*X[i,2])*eta[2])
  
  X[i,1:3]<-pmax(X[i,1:3],0)###boundary condition to prevent negative values
  X[i,1:3]<-pmin(X[i,1:3],N)###boundary condition to prevent values larger than N
}
X$days<-timesteps

library(ggplot2)
X%>%
  pivot_longer(col=-c(days))%>%
  ggplot(aes(x=days,y=value))+
  geom_line(aes(color=name))+
  scale_color_discrete(name="compartment")+
  scale_y_continuous("hosts")+
  theme_bw()->sir_EM


ggsave("sir_EM_plot.png",width = 6,height=3.5,
       sir_EM)
