library(tidyverse)

##simple Ross-McDonald model, rates per day
finalT=365*2
H <- 1000
VectorHumanRatio<-2
VectorBirthDeathRatio<-1##demographic equilibrium
AverageDurationUntreatedInfection<-30
parms <- c(alpha=0.08, 
           gamma=1/AverageDurationUntreatedInfection, 
           beta=0.05, 
           mu=1/10)
parms[["delta"]]<-parms[["mu"]]*VectorBirthDeathRatio
###basic reproduction number:
R0=sqrt(parms[["alpha"]]*parms[["beta"]]*VectorHumanRatio/(parms[["mu"]]*parms[["gamma"]]))
print(paste0("R0 is: ",round(R0,4)))
I0 <- 1
V0 <- 8
x0 <- c(S=H-I0,I=I0,U=H*VectorHumanRatio-V0,V=V0)

##Ross-McDonald with Euler-Maruyama
G_mat<-function(state){
  S=state[1];I=state[2];U=state[3];V=state[4]
  
  Gmatrix<-list()
  Gmatrix[[1]]<-c(-sqrt(alpha*V*S/H),sqrt(gamma*I),0,0,0,0,0)
  Gmatrix[[2]]<-c(sqrt(alpha*V*S/H),-sqrt(gamma*I),0,0,0,0,0)
  Gmatrix[[3]]<-c(0,0,-sqrt(beta*U*I/H),sqrt(mu*U),sqrt(mu*V),-sqrt(delta*U),0)
  Gmatrix[[4]]<-c(0,0,sqrt(beta*U*I/H),0,0,0,-sqrt(delta*V))

  Gmatrix<-matrix(
    as.numeric(do.call(rbind,Gmatrix)),
    nrow=4)
  
  
return(Gmatrix)
}

f_fct<-function(state){
  S=state[1];I=state[2];U=state[3];V=state[4]
  f_function<-as.numeric(
    c(-alpha*V*S/H+gamma*I,
       alpha*V*S/H-gamma*I,
      -beta*U*I/H+mu*U+mu*V-delta*U,
       beta*U*I/H-delta*V))
  return(f_function)
}

##Euler scheme: X(t+Delta)=X(t)+f(X(t))Delta+G(X(t))*eta*sqrt(Delta)
alpha=parms[["alpha"]]
gamma=parms[["gamma"]]
beta=parms[["beta"]]
mu=parms[["mu"]]
delta=parms[["delta"]]

deltaT=1
times<-seq(0,finalT,by=deltaT)
X<-data.frame(
  matrix(rep(0,length(times)*4),nrow=length(times))
)
names(X)<-c("S","I","U","V")
X$t<-times

output<-list()
for(s in c(1:10)){
set.seed(s)
X[1,1:4]<-x0
for (i in c(2:nrow(X))){
X[i,1:4]<-X[i-1,1:4]+
  t(f_fct(X[i-1,1:4]))*deltaT+
  1*t(G_mat(X[i-1,1:4])%*%matrix(rnorm(7),nrow=7)*sqrt(deltaT))
}
output[[s]]<-X
}

output%>%
  bind_rows(.id = "seed")%>%
  pivot_longer(cols=-c(t,seed))%>%
  mutate(grouping=paste0(seed,name))%>%
  ggplot()+
  geom_line(aes(x=t,y=value,group=seed),color="grey")+
  geom_smooth(aes(x=t,y=value),color="blue")+
  facet_wrap(~name,scale="free")+
  theme_bw()->RM_EM_plot

ggsave("EulerMaruyma_malariatoy.png",width=6,height = 2.5)
RM_EM_plot
dev.off()
